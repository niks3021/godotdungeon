extends State

@onready var enemy: EnemyRolling = get_owner()
var knockback_velocity: Vector2 = Vector2.ZERO

func enter(data = null) -> void:
	if data is Vector2:
		knockback_velocity = data
	enemy.sprite.play("roll")

func physics_update(delta: float) -> void:
	if not enemy.is_on_floor():
		enemy.velocity += enemy.get_gravity() * delta

	knockback_velocity = knockback_velocity.move_toward(Vector2.ZERO, 800 * delta)
	enemy.velocity.x = knockback_velocity.x
	
	enemy.move_and_slide()
	
	if knockback_velocity.length() <= 10:
		transitioned.emit("rolling")
