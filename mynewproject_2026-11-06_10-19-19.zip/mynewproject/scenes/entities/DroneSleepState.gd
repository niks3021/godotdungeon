extends State

@onready var drone: Drone = get_owner()

func enter(_data = null) -> void:
	if drone.anim_sprite:
		drone.anim_sprite.play("idle(sleep)")
	_start_sleep_cycle()

func update(delta: float) -> void:
	if drone.anim_sprite:
		drone.anim_sprite.position.y = move_toward(drone.anim_sprite.position.y, 0.0, 50.0 * delta)
	drone.bobbing_time = 0.0
	
	if drone.target and is_instance_valid(drone.target):
		transitioned.emit("angry")

func _start_sleep_cycle() -> void:
	await get_tree().create_timer(drone.sleep_idle_cycle_time).timeout
	if not is_inside_tree() or drone.state_machine.current_state != self:
		return
	_start_sleep_cycle()
