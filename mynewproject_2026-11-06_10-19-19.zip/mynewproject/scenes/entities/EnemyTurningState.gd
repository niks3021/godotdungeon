extends State

@onready var enemy: EnemyRolling = get_owner()

func enter(_data = null) -> void:
	enemy.velocity.x = 0.0
	enemy.sprite.rotation_degrees = 0.0 
	enemy.sprite.play("peek_out")
	enemy.sprite.animation_finished.connect(_on_animation_finished)

func exit() -> void:
	if enemy.sprite.animation_finished.is_connected(_on_animation_finished):
		enemy.sprite.animation_finished.disconnect(_on_animation_finished)

func physics_update(delta: float) -> void:
	if not enemy.is_on_floor():
		enemy.velocity += enemy.get_gravity() * delta
	enemy.move_and_slide()

func _on_animation_finished() -> void:
	if enemy.sprite.animation == "peek_out":
		enemy.direction *= -1.0
		enemy.rays_container.scale.x *= -1
		enemy.sprite.play("retract")
		
	elif enemy.sprite.animation == "retract":
		transitioned.emit("rolling")
