extends State

@onready var enemy: EnemyRolling = get_owner()

func enter(_data = null) -> void:
	enemy.velocity = Vector2.ZERO
	
	if enemy.has_node("worldcolider"):
		enemy.get_node("worldcolider").set_deferred("disabled", true)
	if enemy.has_node("hurtbox"):
		enemy.get_node("hurtbox").set_deferred("monitoring", false)
		enemy.get_node("hurtbox").set_deferred("monitorable", false)
	if enemy.has_node("hitbox?"):
		enemy.get_node("hitbox?").set_deferred("monitoring", false)
		enemy.get_node("hitbox?").set_deferred("monitorable", false)
		
	enemy.z_index = 2
	enemy.sprite.rotation_degrees = 0.0
	
	if enemy.sprite.sprite_frames.has_animation("death"):
		enemy.sprite.play("death")
	else:
		enemy.sprite.play("peek_out")
		
	if not enemy.sprite.animation_finished.is_connected(_on_death_animation_finished):
		enemy.sprite.animation_finished.connect(_on_death_animation_finished)

func exit() -> void:
	if enemy.sprite.animation_finished.is_connected(_on_death_animation_finished):
		enemy.sprite.animation_finished.disconnect(_on_death_animation_finished)

func physics_update(_delta: float) -> void:
	pass

func _on_death_animation_finished() -> void:
	enemy.queue_free()
