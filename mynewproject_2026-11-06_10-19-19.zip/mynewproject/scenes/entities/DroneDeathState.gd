extends State

@onready var drone: Drone = get_owner()

func enter(_data = null) -> void:
	drone.enemy_body.velocity = Vector2.ZERO
	
	if drone.has_node("Triggerzone/triggershape"):
		drone.get_node("Triggerzone/triggershape").set_deferred("disabled", true)
	if drone.enemy_body.has_node("worldcolider"):
		drone.enemy_body.get_node("worldcolider").set_deferred("disabled", true)
	if drone.enemy_body.has_node("hurtbox"):
		drone.enemy_body.get_node("hurtbox").set_deferred("monitorable", false)
		drone.enemy_body.get_node("hurtbox").set_deferred("monitoring", false)
		
	drone.z_index = 2
	
	if drone.anim_sprite and drone.anim_sprite.sprite_frames.has_animation("death"):
		drone.anim_sprite.play("death")
		if not drone.anim_sprite.animation_finished.is_connected(_on_death_animation_finished):
			drone.anim_sprite.animation_finished.connect(_on_death_animation_finished)
	else:
		await drone.get_tree().create_timer(0.5).timeout
		_on_death_animation_finished()

func exit() -> void:
	if drone.anim_sprite and drone.anim_sprite.animation_finished.is_connected(_on_death_animation_finished):
		drone.anim_sprite.animation_finished.disconnect(_on_death_animation_finished)

func physics_update(_delta: float) -> void:
	pass

func _on_death_animation_finished() -> void:
	drone.queue_free()
