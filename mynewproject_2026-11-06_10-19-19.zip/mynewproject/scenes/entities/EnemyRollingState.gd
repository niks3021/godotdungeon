extends State

@onready var enemy: EnemyRolling = get_owner()

var speed_multiplier: float = 1.0
var total_degrees_rolled: float = 0.0

func enter(_data = null) -> void:
	enemy.sprite.play("roll")

func physics_update(delta: float) -> void:
	if not enemy.is_on_floor():
		enemy.velocity += enemy.get_gravity() * delta

	# Compute and update rolling visuals
	var frame_rotation = (enemy.roll_rotation_speed * speed_multiplier) * enemy.direction * delta
	enemy.sprite.rotation_degrees += frame_rotation

	total_degrees_rolled += abs(frame_rotation)
	if total_degrees_rolled >= 360.0:
		total_degrees_rolled -= 360.0 
		speed_multiplier = min(speed_multiplier + enemy.speed_increase_per_rotation, enemy.max_speed_multiplier)
	
	if enemy.is_on_floor() and (enemy.ray_forward.is_colliding() or not enemy.ray_down.is_colliding()):
		transitioned.emit("turning")
		return

	enemy.velocity.x = enemy.direction * enemy.speed * speed_multiplier
	enemy.move_and_slide()
