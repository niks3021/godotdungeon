extends State

@onready var drone: Drone = get_owner()
var is_attacking: bool = false

func enter(_data = null) -> void:
	if drone.anim_sprite:
		if not drone.anim_sprite.frame_changed.is_connected(_on_animation_frame_changed):
			drone.anim_sprite.frame_changed.connect(_on_animation_frame_changed)
			
		if drone.anim_sprite.animation == "idle(sleep)":
			drone.anim_sprite.play("sleep-angry")
		else:
			drone.anim_sprite.play("attack(angry)")

func exit() -> void:
	if drone.anim_sprite and drone.anim_sprite.frame_changed.is_connected(_on_animation_frame_changed):
		drone.anim_sprite.frame_changed.disconnect(_on_animation_frame_changed)

func physics_update(delta: float) -> void:
	drone.bobbing_time += delta * drone.bobbing_frequency
	if drone.anim_sprite:
		drone.anim_sprite.position.y = sin(drone.bobbing_time) * drone.bobbing_amplitude

	if not drone.target or not is_instance_valid(drone.target) or drone.knockback_velocity.length() > 10:
		return
		
	var vector_to_player = drone.target.global_position - drone.enemy_body.global_position
	var current_dist = vector_to_player.length()
	
	if current_dist < 1.0: 
		return
		
	var direction = vector_to_player.normalized()
	if direction.x != 0 and drone.anim_sprite:
		drone.anim_sprite.flip_h = (direction.x < 0)
		
	var target_velocity = Vector2.ZERO
	
	# Position tracking calculation
	if current_dist > (drone.target_distance + drone.distance_tolerance):
		target_velocity = direction * drone.SPEED
		if drone.anim_sprite and drone.anim_sprite.animation != "sleep-angry":
			drone.anim_sprite.play("attack(angry)")
	elif current_dist < (drone.target_distance - drone.distance_tolerance):
		target_velocity = -direction * (drone.SPEED * 0.8)
		if drone.anim_sprite and drone.anim_sprite.animation != "sleep-angry":
			drone.anim_sprite.play("attack(angry)")
	else:
		if not is_attacking:
			_trigger_attack_sequence()
			
	drone.enemy_body.velocity = drone.enemy_body.velocity.lerp(target_velocity, drone.acceleration_weight)
	drone.enemy_body.move_and_slide()

func _trigger_attack_sequence() -> void:
	is_attacking = true
	if drone.anim_sprite:
		drone.anim_sprite.play("attack(angry)")
	await get_tree().create_timer(drone.attack_cooldown).timeout
	is_attacking = false

func _on_animation_frame_changed() -> void:
	if drone.anim_sprite and drone.anim_sprite.animation == "attack(angry)":
		if drone.anim_sprite.frame == 0:
			drone.is_charging_laser = true
		if drone.anim_sprite.frame == 3 and drone.target and is_instance_valid(drone.target):
			drone.locked_laser_direction = (drone.target.global_position - drone.enemy_body.global_position).normalized()
		if drone.anim_sprite.frame == 5:
			drone.is_charging_laser = false
			drone.queue_redraw()
			drone._fire_instant_laser()
