extends State

@onready var drone: Drone = get_owner()
var is_lingering: bool = false
var linger_timer: float = 0.0
var is_landing: bool = false

func enter(_data = null) -> void:
	if drone.anim_sprite:
		drone.anim_sprite.play("attack(angry)")
	
	is_lingering = true
	is_landing = false
	linger_timer = drone.linger_time 

func physics_update(delta: float) -> void:
	# ⚡ INSTANT BYPASS: Check this at the absolute top of the loop!
	if drone.target and is_instance_valid(drone.target):
		is_lingering = false
		is_landing = false
		transitioned.emit("angry")
		return

	drone.bobbing_time += delta * drone.bobbing_frequency
	if drone.anim_sprite and not is_landing:
		drone.anim_sprite.position.y = sin(drone.bobbing_time) * drone.bobbing_amplitude

	if is_lingering:
		# If we are in the landing animation phase, don't tick down the wander timer
		if not is_landing:
			linger_timer -= delta
			drone.enemy_body.velocity = Vector2.ZERO
			drone.enemy_body.move_and_slide()
			
			if linger_timer <= 0.0:
				is_lingering = false 
		return

	_move_towards_home(delta)

func _move_towards_home(_delta: float) -> void:
	if drone.knockback_velocity.length() > 10:
		return
		
	var home_target_pos: Vector2
	var custom_zone_active = false
	
	if drone.home_zone and is_instance_valid(drone.home_zone):
		home_target_pos = drone.home_zone.global_position
		custom_zone_active = true
	else:
		home_target_pos = drone.global_position + Vector2(0, (drone.trigger_size.y / 2.0) - drone.sleep_landing_offset)
		
	var distance_to_home = drone.enemy_body.global_position.distance_to(home_target_pos)
	
	if (custom_zone_active and distance_to_home <= 8.0) or (not custom_zone_active and (distance_to_home <= 8.0 or drone.enemy_body.is_on_floor() or (drone.landing_ray and drone.landing_ray.is_colliding() and drone.enemy_body.global_position.distance_to(drone.landing_ray.get_collision_point()) <= drone.sleep_landing_offset))):
		drone.enemy_body.velocity = Vector2.ZERO
		drone.enemy_body.global_position = home_target_pos
		
		# Set states to lock normal flight physics
		is_lingering = true
		is_landing = true
		
		if drone.anim_sprite:
			drone.anim_sprite.play("angry-sleep")
		
		# Safe scene timer that will be safely bypassed by the top physics check if you walk in
		await get_tree().create_timer(0.4).timeout
		
		if not is_inside_tree() or drone.state_machine.current_state != self:
			return
			
		transitioned.emit("sleep")
		return
		
	var horizontal_distance = abs(drone.enemy_body.global_position.x - home_target_pos.x)
	var direction = Vector2.ZERO
	
	if horizontal_distance > 5.0:
		var target_x_pos = Vector2(home_target_pos.x, drone.enemy_body.global_position.y)
		direction = (target_x_pos - drone.enemy_body.global_position).normalized()
	else:
		direction = (home_target_pos - drone.enemy_body.global_position).normalized()
		
	if direction.x != 0 and drone.anim_sprite:
		drone.anim_sprite.flip_h = (direction.x < 0)
		
	var target_home_velocity = direction * drone.SPEED
	drone.enemy_body.velocity = drone.enemy_body.velocity.lerp(target_home_velocity, drone.acceleration_weight)
	drone.enemy_body.move_and_slide()
