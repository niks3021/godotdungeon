@tool
extends Node2D
class_name RoomBoundary

enum TrackingMode {
	FOLLOW_PLAYER,    
	LOCK_TO_FOCAL,     
	LOCK_X_ONLY,       
	LOCK_Y_ONLY        
}

@export var tracking_mode: TrackingMode = TrackingMode.FOLLOW_PLAYER

@export var room_size: Vector2 = Vector2(512, 300):
	set(value):
		room_size = value
		update_collision_shape()
		queue_redraw()

var focus_marker: Marker2D = null
@onready var collision_shape: CollisionShape2D = $Area2D/CollisionShape2D

func _ready() -> void:
	update_collision_shape()
	ensure_focus_marker()

func _process(_delta: float) -> void:
	if Engine.is_editor_hint():
		ensure_focus_marker()
		if is_instance_valid(focus_marker):
			queue_redraw()

func _draw() -> void:
	if Engine.is_editor_hint():
		var rect = Rect2(-room_size / 2, room_size)
		draw_rect(rect, Color(0.682, 0.502, 0.0, 0.435), true)     
		draw_rect(rect, Color(0.781, 0.663, 0.0, 0.6), false, 2.0)  
		
		ensure_focus_marker()
		if is_instance_valid(focus_marker):
			draw_line(Vector2.ZERO, focus_marker.position, Color(1.0, 0.3, 0.3, 0.8), 2.0)

func update_collision_shape() -> void:
	if not is_instance_valid(collision_shape):
		collision_shape = get_node_or_null("Area2D/CollisionShape2D")
		
	if is_instance_valid(collision_shape) and collision_shape.shape is RectangleShape2D:
		if Engine.is_editor_hint() and collision_shape.shape:
			collision_shape.shape = collision_shape.shape.duplicate()
		collision_shape.shape.size = room_size

func ensure_focus_marker() -> void:
	if not is_instance_valid(focus_marker):
		focus_marker = get_node_or_null("Marker2D") as Marker2D
