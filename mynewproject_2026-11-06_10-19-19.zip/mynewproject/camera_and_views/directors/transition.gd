@tool
extends Area2D
class_name RoomTrigger

@export var room_a: RoomBoundary
@export var room_b: RoomBoundary

@export var trigger_size: Vector2 = Vector2(32, 64):
	set(value):
		trigger_size = value
		if is_inside_tree() and has_node("CollisionShape2D") and $CollisionShape2D.shape:
			$CollisionShape2D.shape.size = trigger_size
		queue_redraw()

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
	if not area_entered.is_connected(_on_area_entered):
		area_entered.connect(_on_area_entered)
	
	if has_node("CollisionShape2D"):
		if not $CollisionShape2D.shape:
			$CollisionShape2D.shape = RectangleShape2D.new()
		$CollisionShape2D.shape.size = trigger_size

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		_trigger_transition()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		_trigger_transition()

func _trigger_transition() -> void:
	var active_room = CameraDirector.current_room
	var target_room: RoomBoundary = null

	if active_room == room_a:
		target_room = room_b
	elif active_room == room_b:
		target_room = room_a
	else:
		target_room = room_a if room_a else room_b

	CameraDirector.transition_to_room(target_room)

func _draw() -> void:
	if Engine.is_editor_hint():
		var rect = Rect2(-trigger_size / 2, trigger_size)
		draw_rect(rect, Color(0.2, 0.6, 1.0, 0.25), true)      
		draw_rect(rect, Color(0.0, 0.8, 1.0, 0.8), false, 1.5) 
