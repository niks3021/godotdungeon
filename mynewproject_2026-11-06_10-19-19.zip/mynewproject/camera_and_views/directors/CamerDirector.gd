extends Node

@export var main_camera: Camera2D
@export var transition_duration: float = 0.45
@export var follow_speed: float = 8.0

var current_room: RoomBoundary = null
var player_node: Node2D = null
var current_tween: Tween
var is_transitioning: bool = false

func _ready() -> void:
	await get_tree().process_frame
	player_node = get_tree().get_first_node_in_group("Player") as Node2D
	if not main_camera:
		main_camera = get_viewport().get_camera_2d()

func _process(delta: float) -> void:
	if not main_camera or not player_node or is_transitioning:
		return
		
	var target_pos: Vector2 = calculate_camera_target()
	
	if current_room and current_room.tracking_mode == RoomBoundary.TrackingMode.LOCK_TO_FOCAL:
		main_camera.global_position = target_pos
	else:
		main_camera.global_position = main_camera.global_position.lerp(target_pos, follow_speed * delta)

func transition_to_room(target_room: RoomBoundary) -> void:
	if current_room == target_room or not player_node or not main_camera:
		current_room = target_room
		return
		
	current_room = target_room
	is_transitioning = true
	
	if current_tween and current_tween.is_running():
		current_tween.kill()
		
	current_tween = create_tween().set_parallel(false)
	
	main_camera.limit_left = -10000000
	main_camera.limit_right = 10000000
	main_camera.limit_top = -10000000
	main_camera.limit_bottom = 10000000
	
	var target_center: Vector2 = calculate_camera_target()
	
	if current_room:
		var half_size = current_room.room_size / 2.0
		var room_left = current_room.global_position.x - half_size.x
		var room_right = current_room.global_position.x + half_size.x
		var room_top = current_room.global_position.y - half_size.y
		var room_bottom = current_room.global_position.y + half_size.y
		
		var half_view = (main_camera.get_viewport_rect().size / main_camera.zoom) / 2.0
		var limit_min_x = min(room_left + half_view.x, room_right - half_view.x)
		var limit_max_x = max(room_left + half_view.x, room_right - half_view.x)
		var limit_min_y = min(room_top + half_view.y, room_bottom - half_view.y)
		var limit_max_y = max(room_top + half_view.y, room_bottom - half_view.y)
		
		target_center.x = clamp(target_center.x, limit_min_x, limit_max_x)
		target_center.y = clamp(target_center.y, limit_min_y, limit_max_y)

	current_tween.tween_property(
		main_camera, 
		"global_position", 
		target_center, 
		transition_duration
	).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	
	current_tween.tween_callback(func():
		if current_room:
			var half_size = current_room.room_size / 2.0
			main_camera.limit_left = int(current_room.global_position.x - half_size.x)
			main_camera.limit_right = int(current_room.global_position.x + half_size.x)
			main_camera.limit_top = int(current_room.global_position.y - half_size.y)
			main_camera.limit_bottom = int(current_room.global_position.y + half_size.y)
		is_transitioning = false
	)

func calculate_camera_target() -> Vector2:
	if not current_room:
		return player_node.global_position
		
	var marker_exists: bool = is_instance_valid(current_room.focus_marker)
	
	var room_center: Vector2 = current_room.global_position
	var marker_pos: Vector2 = current_room.focus_marker.global_position if marker_exists else room_center

	match current_room.tracking_mode:
		RoomBoundary.TrackingMode.LOCK_TO_FOCAL:
			return marker_pos
			
		RoomBoundary.TrackingMode.LOCK_X_ONLY:
			return Vector2(marker_pos.x, room_center.y)
			
		RoomBoundary.TrackingMode.LOCK_Y_ONLY:
			return Vector2(room_center.x, marker_pos.y)
			
		RoomBoundary.TrackingMode.FOLLOW_PLAYER:
			return player_node.global_position
			
		_:
			return player_node.global_position
