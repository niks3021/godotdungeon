extends Node
class_name StateMachine

@export var initial_state: State

var current_state: State
var previous_state: State 
var states: Dictionary = {}

func _ready() -> void:
	for child in get_children():
		if child is State:
			child.state_machine = self 
			states[child.name.to_lower()] = child
			child.transitioned.connect(_on_state_transition)
	
	if initial_state:
		current_state = initial_state
		current_state.call_deferred("enter", null) 
func _process(delta: float) -> void:
	if current_state:
		current_state.update(delta)

func _physics_process(delta: float) -> void:
	if current_state:
		current_state.physics_update(delta)

func _on_state_transition(new_state_name: String) -> void:
	change_state_with_data(new_state_name, null)

func change_state_with_data(new_state_name: String, data = null) -> void:
	if current_state and current_state.name.to_lower() == "death":
		return
		
	var target_state = states.get(new_state_name.to_lower())
	if not target_state: 
		return
		
	if current_state:
		current_state.exit()
		previous_state = current_state 
	current_state = target_state
	current_state.enter(data)
