extends CharacterBody2D

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

@onready var hitbox: Area2D = $hitbox
@onready var hitbox_collider: CollisionShape2D = $hitbox/CollisionShape2D
@onready var attack_effect_sprite: AnimatedSprite2D = $"hitbox/attack frame"

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

var is_attacking: bool = false


func _ready() -> void:
	animated_sprite.animation_finished.connect(_on_animation_finished)
	
	animated_sprite.frame_changed.connect(_on_character_frame_changed)
	
	hitbox_collider.set_deferred("disabled", true)
	attack_effect_sprite.visible = false

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		
	if Input.is_action_just_pressed("attack") and not is_attacking:
		trigger_attack()

	var direction := Input.get_axis("left", "right")
	
	if not is_attacking:
		if direction != 0:
			velocity.x = direction * SPEED
			animated_sprite.flip_h = (direction < 0)
			hitbox.scale.x = -1.0 if direction < 0 else 1.0
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED * 2)

	move_and_slide()
	
	if not is_attacking:
		update_animations(direction)

func trigger_attack() -> void:
	is_attacking = true
	animated_sprite.play("attack")
	velocity.x = 0
	
	attack_effect_sprite.visible = false
	hitbox_collider.set_deferred("disabled", true)

func _on_character_frame_changed() -> void:
	# Only execute this check if the player is actively playing the "attack" sequence
	if is_attacking and animated_sprite.animation == "attack":
		
		if animated_sprite.frame == 6:
			attack_effect_sprite.visible = true
			attack_effect_sprite.play("default") # Change "default" to whatever your smear animation name is
			
			hitbox_collider.set_deferred("disabled", false)

func update_animations(direction: float) -> void:
	if not is_on_floor():
		if velocity.y < 0:
			animated_sprite.play("run") 
		else:  
			animated_sprite.play("jump") 
	else:
		if direction != 0:
			animated_sprite.play("run")
		else:
			animated_sprite.play("idle")

func _on_animation_finished() -> void:
	if animated_sprite.animation == "attack":
		is_attacking = false
		
		attack_effect_sprite.stop()
		attack_effect_sprite.visible = false
		hitbox_collider.set_deferred("disabled", true)


func _on_hitbox_area_entered(_area: Area2D) -> void:

	print("attacked")
