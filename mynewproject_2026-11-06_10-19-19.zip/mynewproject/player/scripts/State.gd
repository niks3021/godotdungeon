extends Node

class_name State

signal transitioned(state_name: String)

var state_machine: StateMachine 

func enter(_data = null) -> void:
	pass

func exit() -> void:
	pass

func update(_delta: float) -> void:
	pass

func physics_update(_delta: float) -> void:
	pass
