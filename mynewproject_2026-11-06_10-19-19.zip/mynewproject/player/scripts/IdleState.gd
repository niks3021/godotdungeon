extends State

@onready var player: Player = get_owner()

func enter(_data = null) -> void:
	player.animated_sprite.play("idle")
	player.velocity.x = move_toward(player.velocity.x, 0, player.SPEED)

func physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	
	if Input.is_action_just_pressed("attack"):
		transitioned.emit("attack")
		return
	elif Input.is_action_just_pressed("heal"):
		transitioned.emit("heal")
		return
	if Input.is_action_just_pressed("jump") and player.is_on_floor():
		transitioned.emit("jump")
		return
	if not player.is_on_floor():
		transitioned.emit("fall")
		return
	var direction = Input.get_axis("left", "right")
	if direction != 0:
		transitioned.emit("run")
		return
		
	player.move_and_slide()
