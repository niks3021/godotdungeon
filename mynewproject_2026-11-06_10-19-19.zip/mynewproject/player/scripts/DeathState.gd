extends State

@onready var player: Player = get_owner()

func enter(_data = null) -> void:
	var current_tree = player.get_tree() 
	if not current_tree: return 
	
	player.velocity = Vector2.ZERO
	player.velocity.y = player.custom_jump_velocity 
	
	player.hitbox_collider.set_deferred("disabled", true)
	if player.has_node("worldcolider"):
		player.get_node("worldcolider").set_deferred("disabled", true)
	
	player.update_health_ui()
	print("Player Died! Reloading environment...")
	
	if player.animated_sprite.sprite_frames.has_animation("death"):
		player.animated_sprite.play("death")
		await player.animated_sprite.animation_finished
	else:
		await current_tree.create_timer(1.0).timeout
		
	if player.has_node("deathscreen"):
		player.get_node("deathscreen").set_deferred("visible", true)
		
	await current_tree.create_timer(2.5).timeout
	current_tree.reload_current_scene()

func physics_update(_delta: float) -> void:
	## Keep applying gravity so the corpse falls out of the screen layout perfectly
	#player.velocity.y += player.fall_gravity * delta
	#player.move_and_slide()
	pass
