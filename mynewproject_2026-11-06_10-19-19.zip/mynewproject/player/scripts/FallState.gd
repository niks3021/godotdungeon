extends State

@onready var player: Player = get_owner()

func enter(_data = null) -> void:
	player.animated_sprite.play("fall") 
		
	var prev = state_machine.get("previous_state")
		
	if prev and prev.name.to_lower() != "jump":
		player.coyote_time.start()
	else:
		player.coyote_time.stop()
			
func physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	
	if Input.is_action_just_pressed("attack"):
		transitioned.emit("attack")
		return
	elif Input.is_action_just_pressed("heal"):
		transitioned.emit("heal")
		return
	elif Input.is_action_just_pressed("jump") and player.coyote_time.time_left > 0 :
		transitioned.emit("jump")
		return
	var direction = Input.get_axis("left", "right")
	player.velocity.x = direction * player.SPEED
	player.update_facing_direction(direction)
	player.move_and_slide()
	
	if player.is_on_floor():
		if direction != 0:
			transitioned.emit("run")
		else:
			transitioned.emit("idle")
