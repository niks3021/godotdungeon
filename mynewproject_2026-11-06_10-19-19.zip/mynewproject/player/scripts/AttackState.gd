extends State

@onready var player: Player = get_owner()

func enter(_data = null) -> void:
	player.animated_sprite.play("attack")
	player.animated_sprite.animation_finished.connect(_on_animation_finished)

	player.hitbox_collider.set_deferred("disabled", false)
	player.attack_effect_sprite.visible = true
	player.attack_effect_sprite.play("default")
	player.attack_timer.start(0.18) 

func exit() -> void:
	if player.animated_sprite.animation_finished.is_connected(_on_animation_finished):
		player.animated_sprite.animation_finished.disconnect(_on_animation_finished)
	player.attack_effect_sprite.stop()
	player.attack_effect_sprite.visible = false
	player.hitbox_collider.set_deferred("disabled", true)

func physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	player.velocity.x = move_toward(player.velocity.x, 0, player.SPEED * 3)
	player.move_and_slide()

func _on_animation_finished() -> void:
	if player.animated_sprite.animation == "attack":
		var direction = Input.get_axis("left", "right")
		if not player.is_on_floor():
			transitioned.emit("fall")
		elif Input.is_action_just_pressed("jump") and player.is_on_floor():
			transitioned.emit("jump")
		elif direction != 0:
			transitioned.emit("run")
		else:
			transitioned.emit("idle")
