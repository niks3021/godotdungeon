extends State

@onready var player: Player = get_owner()

func enter(_data = null) -> void:
	player.velocity.y = player.custom_jump_velocity
	player.animated_sprite.play("jump")

func physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	
	if Input.is_action_just_released("jump") and player.velocity.y < 0:
		player.velocity.y *= player.clamp_to_jump
		
	if Input.is_action_just_pressed("attack"):
		transitioned.emit("attack")
		return
	elif Input.is_action_just_pressed("heal"):
		transitioned.emit("heal")
		return
	var direction = Input.get_axis("left", "right")
	player.velocity.x = direction * player.SPEED
	player.update_facing_direction(direction)
	player.move_and_slide()
	
	if player.velocity.y >= 0:
		transitioned.emit("fall")
