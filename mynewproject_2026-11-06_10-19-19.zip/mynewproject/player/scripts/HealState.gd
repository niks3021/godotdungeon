extends State

@onready var player: Player = get_owner()
var is_interrupting: bool = false

func enter(_data = null) -> void:
	is_interrupting = false
	
	# 1. Energy Check
	if player.current_energy < player.total_energy_required:
		transition()
		return
		
	# 2. Deduct initial cost & play animation
	player.current_energy -= player.initial_cost
	player.update_energy_ui()
	player.animated_sprite.play("heal")
	
	# 3. Wait for the animation frame-by-frame instead of blocking execution
	await player.animated_sprite.animation_finished
	
	# 4. If we interrupted during the await, stop here
	if is_interrupting or state_machine.current_state != self:
		return
		
	# 5. Check if they let go right at the finish frame
	if not Input.is_action_pressed("heal"):
		trigger_interrupt()
		return
		
	# 6. Successful heal completion
	player.heal(player.heal_amount)
	player.current_energy -= player.sucess_cost
	player.update_energy_ui()
	transition()

func handle_input(event: InputEvent) -> void:
	# Interrupt instantly if they release the button mid-heal
	if event.is_action_released("heal") and not is_interrupting:
		trigger_interrupt()

func trigger_interrupt() -> void:
	is_interrupting = true
	player.animated_sprite.stop()
	
	player.animated_sprite.play("healinterupt")
	
	await player.animated_sprite.animation_finished
		
	transition()

func transition() -> void:
	var direction = Input.get_axis("left", "right")
	if not player.is_on_floor():
		transitioned.emit("fall")
	elif Input.is_action_just_pressed("jump") and player.is_on_floor():
		transitioned.emit("jump")
	elif direction != 0:
		transitioned.emit("run")
	else:
		transitioned.emit("idle")
