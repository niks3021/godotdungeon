extends State

@onready var player: Player = get_owner()
var current_knockback: Vector2 = Vector2.ZERO

func enter(data = null) -> void:
	if data is Vector2:
		current_knockback = data
	player.animated_sprite.play("idle") # Or a hit animation if available

func physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	
	current_knockback = current_knockback.move_toward(Vector2.ZERO, 1000 * delta)
	player.velocity.x = current_knockback.x
	player.move_and_slide()
	
	if current_knockback.length() <= 20:
		if player.is_on_floor():
			transitioned.emit("idle")
		else:
			transitioned.emit("fall")
