extends CharacterBody2D
class_name EnemyRolling

@export var speed: float = 50.0
@export var max_health: int = 2
@export var roll_rotation_speed: float = 360.0 
@export var speed_increase_per_rotation: float = 0.15 
@export var max_speed_multiplier: float = 2.5
@export var iframeduration: float = 0.5

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var rays_container: Node2D = $RaysForpath
@onready var ray_forward: RayCast2D = $RaysForpath/RayForward
@onready var ray_down: RayCast2D = $RaysForpath/RayDown
@onready var state_machine: StateMachine = $StateMachine

var is_invincible: bool = false
var direction: float = 1.0
var current_health: int = max_health
var is_dead: bool = false

func _ready() -> void:
	current_health = max_health
	
	if not $"hitbox?".area_entered.is_connected(_on_hitbox_area_entered):
		$"hitbox?".area_entered.connect(_on_hitbox_area_entered)

func take_damage(amount: int = 1, attacker_position: Vector2 = Vector2.ZERO) -> void:
	if is_dead or is_invincible: return 
	
	# Only allow damage while rolling (as dictated by your original logic)
	if state_machine.current_state.name.to_lower() != "rolling": return
	
	current_health -= amount
	print("Enemy hit! Remaining health: ", current_health)
	
	if current_health <= 0:
		die()
	else:
		trigger_i_frames()
		play_flash_visual()
		
		# Force shift FSM into knockback state, passing target direction data
		var knock_dir = (global_position - attacker_position).normalized()
		var calculated_knockback = Vector2(knock_dir.x * 250.0, -150.0)
		state_machine.change_state_with_data("knockback", calculated_knockback)

func trigger_i_frames() -> void:
	is_invincible = true
	await get_tree().create_timer(iframeduration).timeout
	is_invincible = false

func play_flash_visual() -> void:
	var flash_mat = sprite.material as ShaderMaterial
	if flash_mat:
		flash_mat.set_shader_parameter("flash_modifier", 1.0)
		await get_tree().create_timer(0.15).timeout
		if is_instance_valid(self) and not is_dead: 
			flash_mat.set_shader_parameter("flash_modifier", 0.0)

func _on_hitbox_area_entered(area: Area2D) -> void:
	if is_dead: return
	print("Enemy hitbox physically touched an area: ", area.name)
	
	if area.is_in_group("player_hurtbox") or area.name == "hurtbox":
		var player_node = area.get_parent()
		if player_node and player_node.has_method("take_damage"):
			player_node.take_damage(1, global_position)

func die() -> void:
	is_dead = true
	state_machine.change_state_with_data("death", null)
