@tool
extends Area2D

@export var collision_shape_2d: CollisionShape2D:
	set(value):
		collision_shape_2d = value
		update_collider_size()

@export var instant_kill: bool = true
@export var damage_amount: int = 1

@export var collider_size: Vector2 = Vector2(50, 50):
	set(value):
		collider_size = value
		update_collider_size()

func _ready() -> void:
	monitoring = true
	monitorable = false
	update_collider_size()
	if not area_entered.is_connected(_on_area_entered):
		area_entered.connect(_on_area_entered)

func _on_area_entered(area: Area2D) -> void:
	if Engine.is_editor_hint(): return 
	if area.name == "hurtbox" or area.is_in_group("player_hurtbox"):
		var player_node = area.get_parent()
		if player_node:
			if instant_kill and player_node.has_method("die"):
				print("Bypassing damage logic -> Forcing player die() directly!")
				player_node.die()
			elif player_node.has_method("take_damage"):
				player_node.take_damage(damage_amount, global_position)

func update_collider_size() -> void:
	if not is_inside_tree() or not collision_shape_2d:
		return
		
	if not collision_shape_2d.shape:
		collision_shape_2d.shape = RectangleShape2D.new()
	else:
		collision_shape_2d.shape = collision_shape_2d.shape.duplicate()
		
	var rect_shape = collision_shape_2d.shape as RectangleShape2D
	if rect_shape:
		rect_shape.size = collider_size
		
		collision_shape_2d.queue_redraw()
		notify_property_list_changed()
