extends Area2D
class_name LaserProjectile

@export var speed: float = 1200.0
var direction: Vector2 = Vector2.RIGHT

var max_travel_distance: float = 1000.0
var current_distance_traveled: float = 0.0

func _ready() -> void:
	rotation = direction.angle()
	
	monitoring = true
	monitorable = false 
	if not area_entered.is_connected(_on_area_entered):
		area_entered.connect(_on_area_entered)
		

func set_max_distance(dist: float) -> void:
	max_travel_distance = dist

func _physics_process(delta: float) -> void:
	var move_step = speed * delta
	global_position += direction * move_step
	
	current_distance_traveled += move_step
	if current_distance_traveled >= max_travel_distance:
		queue_free()

func _on_area_entered(area: Area2D) -> void:
	
	var area_name_lower = area.name.to_lower()
	
	if area.is_in_group("player_hurtbox") or area_name_lower == "hurtbox":
		
		var player_node = area.get_parent()
		if player_node and player_node.has_method("take_damage"):
				player_node.take_damage(1, global_position)
				queue_free() 
