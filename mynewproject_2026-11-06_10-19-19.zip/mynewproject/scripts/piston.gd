extends AnimatableBody2D

@export_subgroup("Initial Setup")
@export var start_delay: float = 0.0

@export_subgroup("Trap Timing")
@export var up_wait_time: float = 1.5      # Time spent resting at the top
@export var down_wait_time: float = 0.5    # Time spent clamped at the bottom

@onready var anim_player: AnimationPlayer = $AnimatableBody2D/AnimationPlayer

func _ready() -> void:
	start_automatic_trap_loop()

func start_automatic_trap_loop() -> void:
	if not anim_player or not anim_player.has_animation("piston"):
		push_error("Piston Error: AnimationPlayer or 'piston' track is missing!")
		return
	if start_delay > 0.0:
		await get_tree().create_timer(start_delay).timeout
	while true:
		await get_tree().create_timer(up_wait_time).timeout
		
		anim_player.play_backwards("piston")
		await anim_player.animation_finished

		await get_tree().create_timer(down_wait_time).timeout
		
		anim_player.play("piston")
		await anim_player.animation_finished
