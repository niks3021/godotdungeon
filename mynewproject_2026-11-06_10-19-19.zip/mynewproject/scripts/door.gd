extends AnimatableBody2D
class_name BaseDoor

@export var invert_logic: bool = false

func _ready() -> void:
	if invert_logic:
		if has_node("AnimationPlayer"):
			$AnimationPlayer.play("opendoor")
		$CollisionShape2D.set_deferred("disabled", true)

func _on_lever_changed(is_on: bool) -> void:
	var final_state: bool = !is_on if invert_logic else is_on

	$CollisionShape2D.set_deferred("disabled", final_state)

	if has_node("AnimationPlayer"):
		if final_state:
			$AnimationPlayer.play("opendoor")
		else:
			$AnimationPlayer.play_backwards("opendoor")
	else:
		visible = not final_state
