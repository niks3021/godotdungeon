@tool
extends AnimatableBody2D

enum RayDirection { UP, DOWN, LEFT, RIGHT }

@export_category("Platform Path")
@export var current_direction: RayDirection = RayDirection.RIGHT:
	set(value):
		current_direction = value
		_update_ray_direction()

@export var ray_length: float = 24.0:
	set(value):
		ray_length = value
		_update_ray_direction()

@export_category("Movement Settings")
@export var speed: float = 100.0
@export var wait_time: float = 0.75

@onready var ray_cast: RayCast2D = $RayCast2D 
var move_direction: Vector2 = Vector2.ZERO

var is_waiting: bool = false
var current_wait_timer: float = 0.0

func _ready() -> void:
	_update_ray_direction()
	if not Engine.is_editor_hint():
		ray_cast.enabled = true

func _update_ray_direction() -> void:
	if not has_node("RayCast2D"): 
		return
		
	var ray = get_node("RayCast2D")
	match current_direction:
		RayDirection.UP: ray.target_position = Vector2.UP * ray_length
		RayDirection.DOWN: ray.target_position = Vector2.DOWN * ray_length
		RayDirection.LEFT: ray.target_position = Vector2.LEFT * ray_length
		RayDirection.RIGHT: ray.target_position = Vector2.RIGHT * ray_length
		
	move_direction = ray.target_position.normalized()

func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint():
		return
		
	if is_waiting:
		current_wait_timer -= delta
		if current_wait_timer <= 0.0:
			is_waiting = false
		return
		
	if ray_cast.is_colliding():
		is_waiting = true
		current_wait_timer = wait_time
		
		match current_direction:
			RayDirection.UP: current_direction = RayDirection.DOWN
			RayDirection.DOWN: current_direction = RayDirection.UP
			RayDirection.LEFT: current_direction = RayDirection.RIGHT
			RayDirection.RIGHT: current_direction = RayDirection.LEFT
			
		ray_cast.force_raycast_update()
		return

	position += move_direction * speed * delta
