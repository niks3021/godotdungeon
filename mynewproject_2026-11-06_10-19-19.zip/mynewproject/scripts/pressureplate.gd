extends AnimatableBody2D

signal plate_pressed(is_pressed: bool)

var is_activated: bool = false
var bodies_inside: int = 0
var leaving_timer: SceneTreeTimer = null

@export var target_door: Node2D 
@export var waitafterleave: float = 1.5

func _ready() -> void:
	if target_door and target_door.has_method("_on_lever_changed"):
		plate_pressed.connect(target_door._on_lever_changed)
	
	$Label.text = ""

func _process(_delta: float) -> void:
	if leaving_timer and leaving_timer.time_left > 0:
		$Label.text = "Closes in: " + str("%.1f" % leaving_timer.time_left)
	else:
		$Label.text = ""

func _on_activate_area_entered(_area: Area2D) -> void:
	bodies_inside += 1
	leaving_timer = null 
	if not is_activated:
		is_activated = true
		$AnimationPlayer.play("pressed")
		plate_pressed.emit(true)

func _on_activate_area_exited(_area: Area2D) -> void:
	bodies_inside -= 1
	if bodies_inside <= 0:
		bodies_inside = 0
		var current_timer = get_tree().create_timer(waitafterleave)
		leaving_timer = current_timer
		await current_timer.timeout
		if leaving_timer == current_timer and is_activated:
			is_activated = false
			$AnimationPlayer.play_backwards("pressed")
			plate_pressed.emit(false)
