extends CharacterBody2D
class_name Player

@export var max_health: int = 6 
@export var SPEED = 300.0

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var hitbox: Area2D = $hitbox
@onready var hurtbox: Area2D = $hurtbox
@onready var hitbox_collider: CollisionShape2D = $hitbox/CollisionShape2D
@onready var attack_effect_sprite: AnimatedSprite2D = $"hitbox/attack frame"
@onready var attack_timer: Timer = $hitbox/Timer
@export var heart_container: HBoxContainer
const HEART_EMPTY = preload("res://player/sprites/emptyheart.png")
const HEART_FULL = preload("res://player/sprites/fulheart.png")
const HEART_HALF = preload("res://player/sprites/halfempty.png")

@export var energybar: TextureProgressBar
@onready var current_energy = 0
@onready var max_energy = 100
@export_category("Energy and healing")
@export var initial_cost:int
@export var sucess_cost:int
@export var heal_amount:int
@onready var total_energy_required:int = initial_cost+sucess_cost
@export_category("jump and buffering")
@export var jump_height: float = 64.0
@export var time_to_peak: float = 0.32
@export var time_to_descent: float = 0.25
@export var clamp_to_jump:float = 0.3
@onready var coyote_time: Timer = $buffers/coyote_time

@onready var jump_gravity: float = (2.0 * jump_height) / (time_to_peak * time_to_peak)
@onready var fall_gravity: float = (2.0 * jump_height) / (time_to_descent * time_to_descent)
@onready var custom_jump_velocity: float = -((2.0 * jump_height) / time_to_peak)

var current_health: int = max_health
var is_invincible: bool = false
var is_dead: bool = false
var energy_tween: Tween
@onready var state_machine: StateMachine = $StateMachine

func _ready() -> void:
	hurtbox.add_to_group("player_hurtbox")
	current_health = max_health
	hitbox_collider.set_deferred("disabled", true)
	attack_effect_sprite.play("default")
	attack_effect_sprite.visible = false
	update_health_ui()
	update_energy_ui()

func apply_gravity(delta: float) -> void:
	if not is_on_floor():
		if velocity.y < 0:
			velocity.y += jump_gravity * delta
		else:
			velocity.y += fall_gravity * delta

func update_facing_direction(direction: float) -> void:
	if direction != 0:
		animated_sprite.flip_h = (direction < 0)
		hitbox.scale.x = -1.0 if direction < 0 else 1.0

func take_damage(amount: int = 1, enemy_position: Vector2 = Vector2.ZERO) -> void:
	if is_dead or is_invincible:
		return
		
	current_health -= amount
	update_health_ui()
	
	if current_health <= 0:
		die()
	else:
		var knock_dir = (global_position - enemy_position).normalized()
		if knock_dir == Vector2.ZERO:
			knock_dir = Vector2.LEFT if animated_sprite.flip_h else Vector2.RIGHT
		var calculated_knockback = Vector2(knock_dir.x * 350.0, -250.0)
		
		play_flash_visual()
		trigger_i_frames()
		state_machine.change_state_with_data("knockback", calculated_knockback)

func heal(amount: int) -> void:
	if is_dead or current_health >= max_health:
		return
		
	current_health += amount
	if current_health > max_health:
		current_health = max_health
		
	update_health_ui()

func trigger_i_frames() -> void:
	is_invincible = true
	var blink_timer = 0.7
	while blink_timer > 0:
		if is_dead:
			break
		animated_sprite.visible = !animated_sprite.visible
		await get_tree().create_timer(0.07).timeout
		blink_timer -= 0.07
		
	if is_instance_valid(self) and not is_dead:
		animated_sprite.visible = true
		is_invincible = false

func play_flash_visual() -> void:
	var flash_mat = animated_sprite.material as ShaderMaterial
	if flash_mat:
		flash_mat.set_shader_parameter("flash_modifier", 1.0)
		await get_tree().create_timer(0.15).timeout
		if is_instance_valid(self) and not is_dead:
			flash_mat.set_shader_parameter("flash_modifier", 0.0)

func update_health_ui() -> void:
	if not heart_container:
		return
		
	var hearts = heart_container.get_children()
	
	for i in range(hearts.size()):
		if hearts[i] is TextureRect:
			var heart_index = i * 2
			
			if current_health >= heart_index + 2:
				hearts[i].texture = HEART_FULL
			elif current_health == heart_index + 1:
				hearts[i].texture = HEART_HALF
			else:
				hearts[i].texture = HEART_EMPTY

func update_energy_ui() -> void:
	if not energybar:
		return
	if current_energy>max_energy:
		current_energy = max_energy
	if energy_tween and energy_tween.is_valid():
		energy_tween.kill()
		
	energy_tween = create_tween()
	energy_tween.tween_property(energybar, "value", current_energy, 0.3)\
		.set_trans(Tween.TRANS_CUBIC)\
		.set_ease(Tween.EASE_OUT)
		
func _on_hitbox_area_entered(_area: Area2D) -> void:
	var hit_target = _area.owner if _area.owner else _area.get_parent()
	if hit_target and hit_target.has_method("take_damage"):
		current_energy+=20
		update_energy_ui()
		hit_target.take_damage(1, global_position)

func die() -> void:
	if is_dead:
		return
	is_dead = true
	state_machine.change_state_with_data("death", null)
