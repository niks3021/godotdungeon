extends Node2D


@export var next_scene: PackedScene


func _on_area_2d_area_entered(_area: Area2D) -> void:
	if next_scene:
		get_tree().call_deferred("change_scene_to_packed", next_scene)
