extends AnimatableBody2D
class_name BaseLever

# Sends out a boolean state: true for ON, false for OFF
signal lever_changed(is_on: bool)

@export var target_door: AnimatableBody2D
@export var single_use_only: bool = false 

var is_activated: bool = false

func _ready() -> void:
	if target_door and target_door.has_method("_on_lever_changed"):
		lever_changed.connect(target_door._on_lever_changed)

func _on_activate_area_entered(_area: Area2D) -> void:
	if is_activated and single_use_only:
		return 
		
	toggle_lever()

func toggle_lever() -> void:
	is_activated = not is_activated
	
	if has_node("AnimationPlayer"):
		if is_activated:
			$AnimationPlayer.play("activate")
		else:
			$AnimationPlayer.play_backwards("activate")
			
	lever_changed.emit(is_activated)
