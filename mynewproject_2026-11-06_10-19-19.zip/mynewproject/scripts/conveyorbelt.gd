@tool
extends Node2D

const TILE_SIZE: int = 16

@export var sprite_sheet: Texture2D
@export var length_in_tiles: int = 5
@export_enum("Left", "Right") var push_direction: String = "Right"
@export var physics_speed: float = 200.0

var scroll_offset: float = 0.0

@onready var area: Area2D = $Area2D
@onready var area_collider: CollisionShape2D = $Area2D/CollisionShape2D
@onready var static_body: StaticBody2D = $StaticBody2D
@onready var solid_collider: CollisionShape2D = $StaticBody2D/CollisionShape2D

func _ready() -> void:
	update_layout()

func _process(delta: float) -> void:
	var synchronized_speed = physics_speed / 4.0
	scroll_offset -= synchronized_speed * delta
	scroll_offset = fposmod(scroll_offset, float(TILE_SIZE))
	queue_redraw()

func update_layout() -> void:
	if not area_collider or not area_collider.shape or not solid_collider or not solid_collider.shape:
		return
	
	var total_width = (length_in_tiles + 2) * TILE_SIZE
	
	var solid_rect = solid_collider.shape as RectangleShape2D
	solid_rect.size = Vector2(total_width, TILE_SIZE)
	solid_collider.position = Vector2(total_width / 2.0, TILE_SIZE / 2.0)
	
	var area_rect = area_collider.shape as RectangleShape2D
	area_rect.size = Vector2(length_in_tiles * TILE_SIZE, TILE_SIZE)
	area_collider.position = Vector2(total_width / 2.0, (TILE_SIZE / 2.0) - 3.0)

func _draw() -> void:
	if not sprite_sheet:
		return
		
	var total_tiles = length_in_tiles + 2
	var total_width = total_tiles * TILE_SIZE
	
	if push_direction == "Left":
		draw_set_transform(Vector2(total_width, 0), 0.0, Vector2(-1, 1))
	else:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	
	var left_src_rect = Rect2(0, 0, TILE_SIZE, TILE_SIZE)
	var right_src_rect = Rect2(TILE_SIZE * 2, 0, TILE_SIZE, TILE_SIZE)
	
	draw_texture_rect_region(sprite_sheet, Rect2(0, 0, TILE_SIZE, TILE_SIZE), left_src_rect)
	draw_texture_rect_region(sprite_sheet, Rect2((total_tiles - 1) * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE), right_src_rect)
	
	for i in range(length_in_tiles + 1):
		var draw_x = TILE_SIZE + (i * TILE_SIZE) - scroll_offset
		var dst_rect = Rect2(draw_x, 0, TILE_SIZE, TILE_SIZE)
		
		var center_src_rect = Rect2(TILE_SIZE, 0, TILE_SIZE, TILE_SIZE)
		
		var min_clip_x = TILE_SIZE
		var max_clip_x = (total_tiles - 1) * TILE_SIZE
		
		if dst_rect.position.x < min_clip_x:
			var diff = min_clip_x - dst_rect.position.x
			dst_rect.position.x += diff
			dst_rect.size.x -= diff
			center_src_rect.position.x += diff
			center_src_rect.size.x -= diff
			
		if dst_rect.end.x > max_clip_x:
			var diff = dst_rect.end.x - max_clip_x
			dst_rect.size.x -= diff
			center_src_rect.size.x -= diff
			
		if dst_rect.size.x > 0:
			draw_texture_rect_region(sprite_sheet, dst_rect, center_src_rect)

func _physics_process(delta: float) -> void:
	for body in area.get_overlapping_bodies():
		if body is CharacterBody2D or body is RigidBody2D:
			if push_direction == "Right":
				body.global_position.x += physics_speed * delta
			else:
				body.global_position.x -= physics_speed * delta
