extends Node2D

@export var wait_time = 1.5
@export var reset_time = 0.5
var isopen = false

func _on_area_2d_area_entered(_area: Area2D) -> void:
	if isopen:
		return
	isopen = true
	
	await get_tree().create_timer(wait_time).timeout
	$AnimationPlayer.play("slide")
	
	await get_tree().create_timer(reset_time).timeout
	$AnimationPlayer.play_backwards("slide")
	
	if $AnimationPlayer.is_playing():
		await $AnimationPlayer.animation_finished
		
	isopen = false
