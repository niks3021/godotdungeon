@tool
extends Node2D
class_name Drone

var target: Area2D
var is_charging_laser: bool = false
var locked_laser_direction: Vector2 = Vector2.ZERO

@export_group("Combat & Projectiles")
@export var projectile_scene: PackedScene

@export_subgroup("Home Setup")
@export var home_zone: Area2D:
	set(value):
		home_zone = value
		update_configuration_warnings()

@export_subgroup("Timers & Speeds")
@export var linger_time: float = 3.5
@export var sleep_idle_cycle_time: float = 5.0
@export var SPEED: float = 150.0

@export_subgroup("Combat Settings")
@export var target_distance: float = 120.0
@export var distance_tolerance: float = 5.0
@export var attack_cooldown: float = 1.5
@export var acceleration_weight: float = 0.1

@export_subgroup("Visual Tuning")
@export var sleep_landing_offset: float = 12.0
@export var bobbing_amplitude: float = 6.0    
@export var bobbing_frequency: float = 4.0    

@export_subgroup("Health & Invincibility")
@export var max_health: int = 3
@export var iframeduration: float = 0.5

@export_subgroup("Editor Configuration")
@export var trigger_size: Vector2 = Vector2(32, 32):
	set(value):
		trigger_size = value
		if is_node_ready() and has_node("Triggerzone/triggershape"):
			var t_shape = $Triggerzone/triggershape.shape
			if t_shape:
				t_shape.size = trigger_size

# --- Components ---
@onready var enemy_body: CharacterBody2D = $CharacterBody2D
@onready var anim_sprite: AnimatedSprite2D = $CharacterBody2D/AnimatedSprite2D
@onready var laser_ray: RayCast2D = $CharacterBody2D/lineofsight
@onready var landing_ray: RayCast2D = $CharacterBody2D/landing_ray
@onready var triggerzone: Area2D = $Triggerzone
@onready var triggershape: CollisionShape2D = $Triggerzone/triggershape
@onready var state_machine: StateMachine = $StateMachine

# --- Global States ---
var current_health: int = max_health
var is_invincible: bool = false
var is_dead: bool = false
var knockback_velocity: Vector2 = Vector2.ZERO
var bobbing_time: float = 0.0

func _ready() -> void:
	current_health = max_health
	
	if triggershape and triggershape.shape:
		if not Engine.is_editor_hint():
			triggershape.shape = triggershape.shape.duplicate()
		triggershape.shape.size = trigger_size
		
	if Engine.is_editor_hint():
		return

func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint() or is_dead:
		return
		
	if is_charging_laser:
		queue_redraw()
		
	# Apply central knockback routines to the underlying character body if active
	if knockback_velocity.length() > 10:
		knockback_velocity = knockback_velocity.move_toward(Vector2.ZERO, 800.0 * delta)
		enemy_body.velocity = knockback_velocity
		enemy_body.move_and_slide()

func take_damage(amount: int = 1, attacker_position: Vector2 = Vector2.ZERO) -> void:
	if is_dead or is_invincible: 
		return
		
	current_health -= amount
	print("Drone hit! Remaining health: ", current_health)
	
	if current_health <= 0:
		die()
	else:
		trigger_i_frames()
		play_flash_visual()
		
		var knock_dir = (enemy_body.global_position - attacker_position).normalized()
		knockback_velocity = Vector2(knock_dir.x * 300.0, -100.0)
		
		# Wake up immediately on hit if currently asleep
		if state_machine.current_state and state_machine.current_state.name.to_lower() == "sleep":
			state_machine.change_state_with_data("angry", null)

func die() -> void:
	is_dead = true
	state_machine.change_state_with_data("death", null)

func play_flash_visual() -> void:
	var flash_mat = anim_sprite.material as ShaderMaterial
	if flash_mat:
		flash_mat.set_shader_parameter("flash_modifier", 1.0)
		await get_tree().create_timer(0.15).timeout
		if is_instance_valid(self) and not is_dead: 
			flash_mat.set_shader_parameter("flash_modifier", 0.0)

func trigger_i_frames() -> void:
	is_invincible = true
	await get_tree().create_timer(iframeduration).timeout
	is_invincible = false

# --- Combat Functions ---
func _fire_instant_laser() -> void:
	if not target or not is_instance_valid(target):
		return
		
	laser_ray.global_position = enemy_body.global_position
	laser_ray.target_position = locked_laser_direction * 1000.0
	laser_ray.force_raycast_update()
	
	var final_impact_point = enemy_body.global_position + (locked_laser_direction * 1000.0)
	if laser_ray.is_colliding():
		final_impact_point = laser_ray.get_collision_point()
			
	if projectile_scene:
		var proj = projectile_scene.instantiate() as Area2D
		proj.global_position = enemy_body.global_position
		# Match standard direction injection property
		if "direction" in proj:
			proj.direction = locked_laser_direction
		get_tree().current_scene.add_child(proj)
		if proj.has_method("set_max_distance"):
			var travel_distance = enemy_body.global_position.distance_to(final_impact_point)
			proj.set_max_distance(travel_distance)

func _draw() -> void:
	if is_charging_laser and target and is_instance_valid(target):
		var target_dir = (target.global_position - enemy_body.global_position).normalized()
		laser_ray.global_position = enemy_body.global_position
		laser_ray.target_position = target_dir * 1000.0
		laser_ray.force_raycast_update()
		
		var visual_endpoint = enemy_body.global_position + (target_dir * 1000.0)
		if laser_ray.is_colliding():
			visual_endpoint = laser_ray.get_collision_point()
			
		var local_start_pos = to_local(enemy_body.global_position)
		var local_end_pos = to_local(visual_endpoint)
		draw_line(local_start_pos, local_end_pos, Color(1, 0, 0, 0.4), 1.5)

# --- Signal Receiver Hooks ---
# Make sure to connect your Triggerzone Area2D signals to these two functions in the editor!
func _on_triggerzone_area_entered(area: Area2D) -> void:
	if area.is_in_group("player_hurtbox") or area.name == "hurtbox":
		target = area
		state_machine.change_state_with_data("angry", null)

func _on_triggerzone_area_exited(area: Area2D) -> void:
	if area == target:
		target = null
		state_machine.change_state_with_data("returning", null)
